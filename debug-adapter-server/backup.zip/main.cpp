#include "debugger.h"
#include "event.h"
#include "session_state.h"

#include "dap/io.h"
#include "dap/network.h"
#include "dap/protocol.h"
#include "dap/session.h"
#include "dap/typeof.h"

#include <chrono>
#include <cstdio>
#include <memory>
#include <string>
#include <thread>

#define USE_SERVER_MODE

namespace dap {

// Custom LaunchRequest to include additional fields
class MyLaunchRequest : public LaunchRequest {
public:
    // The program executable path.
    dap::string program;

    // Command line arguments for the program.
    optional<array<string>> args;

    // Whether to stop at the entry point of the program.
    optional<boolean> stopOnEntry;
};

DAP_STRUCT_TYPEINFO_EXT(
    MyLaunchRequest,
    LaunchRequest,
    "launch",
    DAP_FIELD(program, "program"),
    DAP_FIELD(args, "args"),
    DAP_FIELD(stopOnEntry, "stopOnEntry"));

} // namespace dap

int main(int, char* []) {
    constexpr int kPort = 19021;

    // Callback handler for a socket connection to the server
    auto onClientConnected = [&](const std::shared_ptr<dap::ReaderWriter>& socket) {
        // Start a new thread for each client connection
        std::thread([socket]() {
            auto session = dap::Session::create();

            // Set the session to close on invalid data
            session->setOnInvalidData(dap::kClose);

            // Signal used to terminate the server session when a DisconnectRequest
            // is made by the client.
            SessionState state;

            // Shared pointer to Debugger instance
            std::shared_ptr<Debugger> debugger;

            // Event handler for Debugger events
            auto debuggerEventHandler = [&session, &state](Debugger::Event event) {
                switch (event) {
                case Debugger::Event::BreakpointHit:
                case Debugger::Event::Stepped:
                case Debugger::Event::Paused: {
                    dap::StoppedEvent stoppedEvent;
                    stoppedEvent.threadId = 1;
                    stoppedEvent.reason = "breakpoint";
                    session->send(stoppedEvent);
                    break;
                }
                case Debugger::Event::Exited: {
                    dap::ExitedEvent exitedEvent;
                    session->send(exitedEvent);

                    // Signal termination
                    {
                        std::lock_guard<std::mutex> lock(state.mutex);
                        state.terminate = true;
                    }
                    state.cv.notify_one();
                    break;
                }
                }
            };

            session->onError([&](const char* msg) {
                printf("Session error: %s\n", msg);
                // Signal termination
                {
                    std::lock_guard<std::mutex> lock(state.mutex);
                    state.terminate = true;
                }
                state.cv.notify_one();
            });

            // Register DAP handlers
            session->registerHandler([&](const dap::InitializeRequest&) {
                dap::InitializeResponse response;
                response.supportsConfigurationDoneRequest = true;
                return response;
            });

            session->registerSentHandler([&](const dap::ResponseOrError<dap::InitializeResponse>&) {
                session->send(dap::InitializedEvent());
            });

            session->registerHandler([&](const dap::MyLaunchRequest& request) {
                // Start the program
                std::string program = request.program;
                std::string args = "";
                if (request.args.has_value()) {
                    for (const auto& arg : request.args.value()) {
                        args += arg + " ";
                    }
                }

                // Create the Debugger instance
                debugger = std::make_shared<Debugger>(debuggerEventHandler);

                // Start the debugger in a new thread
                std::thread([debugger, program, args]() {
                    debugger->launch(program, args);
                    debugger->eventLoop();
                }).detach();

                return dap::LaunchResponse();
            });

            session->registerHandler([&](const dap::ConfigurationDoneRequest&) {
                return dap::ConfigurationDoneResponse();
            });

            session->registerHandler([&](const dap::SetBreakpointsRequest& request) {
                std::vector<dap::integer> lines;
                for (const auto& bp : request.breakpoints.value({})) {
                    lines.push_back(bp.line);
                }

                if (debugger) {
                    debugger->setBreakpoints(request.source.path.value(""), lines);
                }

                dap::SetBreakpointsResponse response;
                for (const auto& line : lines) {
                    dap::Breakpoint breakpoint;
                    breakpoint.verified = true;
                    breakpoint.line = line;
                    response.breakpoints.push_back(breakpoint);
                }
                return response;
            });

            session->registerHandler([&](const dap::ThreadsRequest&) {
                dap::ThreadsResponse response;
                dap::Thread thread;
                thread.id = 1;
                thread.name = "Main Thread";
                response.threads.push_back(thread);
                return response;
            });

            session->registerHandler([&](const dap::StackTraceRequest&) {
                dap::StackTraceResponse response;
                if (debugger) {
                    response.stackFrames = debugger->getCallStack();
                }
                return response;
            });

            session->registerHandler([&](const dap::ScopesRequest&) {
                dap::ScopesResponse response;
                dap::Scope scope;
                scope.name = "Registers";
                scope.variablesReference = 1;
                scope.presentationHint = "registers";
                response.scopes.push_back(scope);
                return response;
            });

            session->registerHandler([&](const dap::VariablesRequest&) {
                dap::VariablesResponse response;
                if (debugger) {
                    auto regs = debugger->getRegisters();
                    for (const auto& reg : regs) {
                        dap::Variable var;
                        size_t eqPos = reg.find('=');
                        if (eqPos != std::string::npos) {
                            var.name = reg.substr(0, eqPos - 1);
                            var.value = reg.substr(eqPos + 2);
                        } else {
                            var.name = reg;
                            var.value = "<unknown>";
                        }
                        response.variables.push_back(var);
                    }
                }
                return response;
            });

            session->registerHandler([&](const dap::ContinueRequest&) {
                if (debugger) {
                    debugger->run();
                }
                dap::ContinueResponse response;
                response.allThreadsContinued = true;
                return response;
            });

            session->registerHandler([&](const dap::PauseRequest&) {
                if (debugger) {
                    debugger->pause();
                }
                return dap::PauseResponse();
            });

            session->registerHandler([&](const dap::NextRequest&) {
                if (debugger) {
                    debugger->stepOver();
                }
                return dap::NextResponse();
            });

            session->registerHandler([&](const dap::StepInRequest&) {
                if (debugger) {
                    debugger->stepInto();
                }
                return dap::StepInResponse();
            });

            session->registerHandler([&](const dap::StepOutRequest&) {
                if (debugger) {
                    debugger->stepOut();
                }
                return dap::StepOutResponse();
            });

            session->registerHandler([&](const dap::DisconnectRequest&) {
                if (debugger) {
                    debugger->exit();
                }
                // Signal termination
                {
                    std::lock_guard<std::mutex> lock(state.mutex);
                    state.terminate = true;
                }
                state.cv.notify_one();
                return dap::DisconnectResponse();
            });

            session->bind(socket);

            // Wait for the client to disconnect before releasing the session and disconnecting the socket
            std::unique_lock<std::mutex> lock(state.mutex);
            state.cv.wait(lock, [&] { return state.terminate; });
            printf("Server closing connection\n");
        }).detach();
    };

    // Error handler
    auto onError = [&](const char* msg) { printf("Server error: %s\n", msg); };

    // Create the network server
    auto server = dap::net::Server::create();
    server->start(kPort, onClientConnected, onError);

    // Keep the server running indefinitely
    std::mutex mutex;
    std::condition_variable cv;
    std::unique_lock<std::mutex> lock(mutex);
    cv.wait(lock);

    return 0;
}
